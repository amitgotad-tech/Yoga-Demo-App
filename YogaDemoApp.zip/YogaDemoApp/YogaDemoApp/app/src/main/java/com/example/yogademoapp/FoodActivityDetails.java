package com.example.yogademoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;

public class FoodActivityDetails extends AppCompatActivity {
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
 TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details);




        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {}
        });

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {}
        });
        AdRequest adRequest1 = new AdRequest.Builder().build();


        mAdView=findViewById(R.id.adView2);
        AdRequest adRequest=new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        textView=findViewById(R.id.txt);
        String dstory=getIntent().getStringExtra("story");
        textView.setText(dstory);

    }

    public void goback(View view) {
        Intent intent=new Intent(FoodActivityDetails.this,FoodActivity.class);
        startActivity(intent);
        finish();

    }

    @Override
    public void onBackPressed() {
         Intent intent=new Intent(FoodActivityDetails.this,FoodActivity.class);
         startActivity(intent);
         finish();
        if (mInterstitialAd != null) {
            mInterstitialAd.show(FoodActivityDetails.this);
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.");
        }
    }
}