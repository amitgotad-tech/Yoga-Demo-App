package com.example.yogademoapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class data1 extends SQLiteOpenHelper {

    private static final String TAG="data1";

    public data1(@Nullable Context context) {
        super(context, "BurnDB.db", null, 21);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table if not exists BurnDB(editText text , editText1 text , editText2 text )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists BurnDB");
        onCreate(sqLiteDatabase);
    }

    public void insertdata(db db){

        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();

        contentValues.put("editText",db.getEditTextText5());
        contentValues.put("editText1",db.getEditTextText4());
        contentValues.put("editText2",db.getEditTextText3());

        long BurnDB = sqLiteDatabase.insert("BurnDB", null,contentValues);
        Log.e(TAG,"insertdata: "+BurnDB);
    }
}
