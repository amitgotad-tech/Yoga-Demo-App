package com.example.yogademoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class feedback extends AppCompatActivity {

    String a,b,c;

    Button button;

    EditText editTextText5,editTextText4,editTextText3;
    public data1 data1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

         editTextText5=findViewById(R.id.editTextText5);
         editTextText4=findViewById(R.id.editTextText4);
         editTextText3=findViewById(R.id.editTextText3);

        button=findViewById(R.id.button);

        data1=new data1(getApplicationContext());

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a=editTextText5.getText().toString();
                b=editTextText4.getText().toString();
                c=editTextText3.getText().toString();
                data1.insertdata(new db(a,b,c));
            }
        });











    }
}