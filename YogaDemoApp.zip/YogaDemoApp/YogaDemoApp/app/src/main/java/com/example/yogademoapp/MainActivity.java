                package com.example.yogademoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

                public class MainActivity extends AppCompatActivity {

    Button button1,button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        androidx.appcompat.widget.Toolbar toolbar=findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);


        button1=findViewById(R.id.startyoga1);
        button2=findViewById(R.id.startyoga2);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,SecondActivity.class);
                startActivity(intent);
            }
        });


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,SecondActivity2.class);
                startActivity(intent);
            }
        });


    }

                    @Override
                    public boolean onCreateOptionsMenu(Menu menu) {
                        getMenuInflater().inflate(R.menu.main,menu);
                        return true;
                    }

                    @Override
                    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
                        int id= item.getItemId();
                        if(id==R.id.id_privacy) {

                      Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://burnoutapp.blogspot.com/2023/09/burnout-privacy-policy_23.html"));
                           //   Intent intent=new Intent(this,feedback.class);
                           // Intent intent= new Intent(this, feedback.class);
                            startActivity(intent);
                            return true;
                        }

                        if(id==R.id.id_term) {
                            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://burnoutapp.blogspot.com/2023/09/burnout-privacy-policy.html"));
                            startActivity(intent);
                            return true;
                        }



                        if(id==R.id.share) {

                            Intent myintent=new Intent(Intent.ACTION_SEND);
                            myintent.setType("text/plain");
                            String sharebody="Hello folks!\n Download this free Exercise Application\n"+"https://play.google.com/store/apps/details?id=com.example.yogademoapp&hl=en";
                            String sharehub="Burn Out";
                            myintent.putExtra(Intent.EXTRA_SUBJECT,sharehub);
                            myintent.putExtra(Intent.EXTRA_TEXT,sharebody);
                            startActivity(Intent.createChooser(myintent,"share using"));



                            return true;
                        }
                        if(id==R.id.feed){
                            Intent intent= new Intent(this, feedback.class);
                            startActivity(intent);
                            return true;

                        }
                        if(id==R.id.feedf) {
                            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://forms.gle/a9JG5QcCkDTusj8j9"));
                            startActivity(intent);
                            return true;
                        }
                        return true;
                    }

                    private void setSupportActionBar(Toolbar toolbar) {
                    }

                    public void Adults(View view) {
                        Intent intent=new Intent(MainActivity.this, SecondActivity2.class);
                        startActivity(intent);
                    }

                    public void food(View view) {
                        Intent intent=new Intent(MainActivity.this,FoodActivity.class);
                        startActivity(intent);
                    }

                    public void Under_18(View view) {
                        Intent intent=new Intent(MainActivity.this,SecondActivity.class);
                        startActivity(intent);
                    }
                }