package com.example.yogademoapp;

public class db {

        private String editTextText5,editTextText4,editTextText3;


    public String getEditTextText5() {
        return editTextText5;
    }

    public void setEditTextText5(String editTextText5) {
        this.editTextText5 = editTextText5;
    }

    public String getEditTextText4() {
        return editTextText4;
    }

    public void setEditTextText4(String editTextText4) {
        this.editTextText4 = editTextText4;
    }

    public String getEditTextText3() {
        return editTextText3;
    }

    public void setEditTextText3(String editTextText3) {
        this.editTextText3 = editTextText3;
    }

    public db(String editTextText5, String editTextText4, String editTextText3) {
            this.editTextText5 = editTextText5;
            this.editTextText4 = editTextText4;
            this.editTextText3 = editTextText3;
        }


    }

